# flywayの利用

コンテナの起動

```bash
cd docker
docker-compose build
docker-compose up -d
docker exec -it flyway bash
```

テーブルの作成

```bash
cd app/
make flyway-init
make project
exit
```

```bash
docker exec -it mysql bash
mysql -u root -ppassword
use project;
desc test_a;
```

```text
+-------+------------------+------+-----+---------+----------------+
| Field | Type             | Null | Key | Default | Extra          |
+-------+------------------+------+-----+---------+----------------+
| id    | int(10) unsigned | NO   | PRI | NULL    | auto_increment |
+-------+------------------+------+-----+---------+----------------+
```


```bash
.
├── Makefile
├── README.md
├── docker
│   ├── build
│   │   └── Dockerfile
│   └── docker-compose.yml
└── sql
    └── main
        └── V1_1__create_table.sql
```