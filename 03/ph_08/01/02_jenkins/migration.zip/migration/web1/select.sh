#!/bin/bash
mysql -uroot -ppassword -h dbserver1 -D project1 -e "select * from account1" > /tmp/web1.txt