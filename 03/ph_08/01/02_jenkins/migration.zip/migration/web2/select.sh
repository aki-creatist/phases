#!/bin/bash
mysql -uroot -ppassword -h dbserver2 -D project2 -e "select * from account2" > /tmp/web2.txt