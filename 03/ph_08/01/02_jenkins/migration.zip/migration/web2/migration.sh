#!/bin/sh

diff /tmp/web1.txt /tmp/web2.txt > /tmp/diff.txt

DATA=$(grep '<' /tmp/diff.txt | cut -f 2 | grep [0-9])

for account in ${DATA}
do
    php /var/www/create_sql.php $account
done

USER=root
PASS=password
NAME=project2

mysql -u${USER} -p${PASS} -h dbserver2 -D ${NAME} < /tmp/query.txt

rm /tmp/diff.txt /tmp/web1.txt /tmp/web2.txt /tmp/query.txt