<?php

$file = '/tmp/query.txt';

$data = "'" . $argv[1] . "'";

$sql  = "INSERT INTO account2 (name) VALUES ($data);\n";

file_put_contents($file, $sql, FILE_APPEND);

