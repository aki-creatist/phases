#!/bin/sh

ssh -y web1 sh /var/www/db_setting.sh
ssh -y web2 sh /var/www/db_setting.sh
