#!/bin/sh

ssh web1 sh /var/www/select.sh
ssh web2 sh /var/www/select.sh

ssh web1 cat /tmp/web1.txt
ssh web2 cat /tmp/web2.txt

echo "web1 scp /tmp/web1.txt web2:/tmp/web1.txt"
ssh web1 scp /tmp/web1.txt web2:/tmp/web1.txt

echo "web1からweb2にscpができたことを確認"
ssh web2 cat /tmp/web1.txt

ssh web2 'sh /var/www/migration.sh'

echo "確認"
ssh web2 sh /var/www/select.sh
ssh web2 cat /tmp/web2.txt