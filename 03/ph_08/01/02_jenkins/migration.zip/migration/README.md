## 概要

![image](image/migrations.png)

## ゴール

テーブルAにのみ存在しているデータを、テーブルBに移行する

```text
A                   B
+------+------+     +------+------+
| id   | name |     | id   | name |
+------+------+     +------+------+
| NULL | 0001 |     | NULL | 0001 |
| NULL | 0003 |     | NULL | 0002 |
+------+------+     +------+------+
```

実行コマンド

```bash
docker exec job sh /var/www/job.sh
```

期待する結果

```text
B
+------+------+
| id   | name |
+------+------+
| NULL | 0001 |
| NULL | 0002 |
| NULL | 0003 |
+------+------+
```

これでweb2コンテナに差分が挿入されれば成功

## サーバ間通信用Docker作成

* jobを実行するjobコンテナから、web1サーバ、web2サーバにssh接続できる環境を作成

### ssh接続の前提条件

* それぞれのサーバにsshがインストールされていること
* 接続される側(web1、web2)が、公開認証が許可されていること
* 接続される側(web1、web2)の、sshデーモンが起動していること

### 鍵による認証の前提条件

* jobコンテナ(接続する側)が秘密鍵(id_rsa)を持っていること
* webコンテナ(接続される側)が、接続する側の秘密鍵(id_rsa)に対応した公開鍵(id_rsa.pub)を持っていること

![image](image/authorized_keys_01.png)

### web1からweb2にsshを繋ぐ

* 今回は同様の手順で、web1からweb2にsshを繋ぐ設定を行う
* web1からweb2に対してファイル転送をすることも想定しているため

![image](image/authorized_keys_02.png)

## 複数サーバにDBを作成する

* web1とweb2に以下のようなテーブルを作成する



# データ移行ジョブの作成

* シェルを実行し、外部サーバから出力ができているかを確認

```bash
#出力の確認
sh job.sh
ssh web1 cat /tmp/web1.txt
ssh web2 cat /tmp/web2.txt
```

* 以下のような結果が得られたら成功

```text
id	name
1	0001
3	0003
id	name
1	0001
2	0002
```
