INSERT INTO `project2`.`account2`
 VALUES
  (1,'0001'),
  (2,'0002');