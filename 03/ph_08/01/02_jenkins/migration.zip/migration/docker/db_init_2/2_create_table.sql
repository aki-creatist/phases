CREATE TABLE IF NOT EXISTS project2.account2(
  id int,
  name varchar(20)
);