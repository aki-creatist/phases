## 事前準備

#### コンテナの起動

```bash
cd docker/
docker-compose build
docker-compose up -d
```

### sshの準備

```bash
ssh-keygen -t rsa -f ssh/id_rsa
=> パスフレーズは決めないのでEnter３回
```

```bash
cat ssh/id_rsa.pub > ssh/authorized_keys
chmod 700 ssh
chmod 600 ssh/authorized_keys
```

```bash
docker exec web1 /etc/init.d/ssh restart
docker exec web2 /etc/init.d/ssh restart
```

#### ssh接続テスト(必須)

ここで一度接続をしておかないとこの後の手順で失敗します。

```bash
docker exec -it job bash
#jobコンテナから各webコンテナに接続テスト
ssh web1
ssh web2

docker exec -it web1 bash
#web1コンテナからweb2コンテナに接続テスト
ssh web2
```

### DB

* DBが作成され、データが挿入されていることを確認

```bash
docker exec mysql1 mysql -uroot -ppassword -Dproject1 -e 'desc account1;'
docker exec mysql1 mysql -uroot -ppassword -Dproject1 -e 'select * from  account1'

docker exec mysql2 mysql -uroot -ppassword -Dproject2 -e 'desc account2;'
docker exec mysql2 mysql -uroot -ppassword -Dproject2 -e 'select * from  account2'

# jobコンテナから確認する場合2
USER=root
PASS=password
NAME1=project1
NAME2=project2

TABLE=account1

SQL1='select * from account1'
SQL2='select * from account2'
ssh web1 "mysql -u${USER} -p${PASS} -h dbserver1 -D ${NAME1} -e '${SQL1}'"
ssh web2 "mysql -u${USER} -p${PASS} -h dbserver2 -D ${NAME2} -e '${SQL2}'"

# webコンテナから確認する場合
mysql -uroot -ppassword -D project1 -e 'select * from  account1'
mysql -uroot -ppassword -D project2 -e 'select * from  account2'
```