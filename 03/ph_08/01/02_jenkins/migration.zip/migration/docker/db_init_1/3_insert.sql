INSERT INTO `project1`.`account1`
 VALUES
  (1,'0001'),
  (3,'0003');